# zjazz AMD miner #

This is a miner for GCN 4th gen AMD GPUs (RX470/RX480/RX580/Vega56/Vega64).

Current release is available for Windows. A Linux release will be released soon.

### Devfee ###

0% devfee for now! In future releases a small devfee might be added.

### Algorithms/Hashrates ###

Phi2 is the only algorithm supported at this moment.

| Algorithm | RX480 | RX580     | Vega64 |
| --------- | ----- | --------- | ------ |
| **phi2**  |       | 1470 kH/s |        |

### Usage ###

For a complete list of options, add --help to command line arguments list.

### License ###

Use -l command line argument to print the full license (including thirdparty software licenses).

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### Donations ###

LUX address: LKTj16Gy6VRrYoQVozNNJLANSKMzpyuKTB



